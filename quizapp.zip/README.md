# Capstone Project (Quiz App)

### This is a group project created by

1. Sri Srinivasan S (Team Leader).
2. Murtuzua Bharmal.
3. Praveen Sajjan.
4. Sayan Sikder.
5. Nikhil Gautam.

## Use the following command to get started :-

- `npm i` or `npm install` to install all the dependencies required.
- `npm start` use this command to start the app.
